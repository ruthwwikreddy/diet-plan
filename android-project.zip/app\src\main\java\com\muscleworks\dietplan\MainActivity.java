package com.muscleworks.dietplan;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
